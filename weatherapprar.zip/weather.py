import requests

city = str(input("Enter City: "))
api = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=a58926ec75f4a5be56140bd1abd56b11&units=metric"

#All features
data = requests.get(api).json() #Get the api in json format
lat, lon = data["coord"]["lat"], data["coord"]["lon"]
temp = data["main"]["temp"]
wind = data["wind"]["speed"]
humidity = data["main"]["humidity"]

print(f'Search City: {city}')
print(f'Latitude: {lat}, Longtitude: {lon}')
print(f'{round(temp,2)}*C')
print(f'Humidity: {humidity}%')
print(f'{wind}m/s')
